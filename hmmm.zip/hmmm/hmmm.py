#Nathan Carpenter
#March 24, 2022
#I pledge my honor that I have abided by the Stevens Honor System

# When this file is loaded, it runs the program assigned
# to variable RunThis. Debug mode is controlled by 
# variable Mode. Read all the comments before trying it out.
# Remember to press F5 to run, after making changes.  

import sys
import importlib
# Also requires hmmmAssembler.py and hmmmSimulator.py to
# be available in the same directory as this file.




Fibonacci = """
0       read    r1         # read n which is the inputted value for the number of integers in the fib seq
1       setn    r2 1       # set r2 = 1 
2       sub     r3 r1 r2   # set r3 = r1 - 1
3       jltzn   r3 16      # if n < 1 goto 16, we stop the function
4       setn    r4 1       # set a = 1 second number in fib seq (larger)
5       setn    r5 0       # set b = 0 first number in fib seq (smaller)
6       setn    r6 1       # set k = 1 the current number in fib seq
7       add     r7 r4 r5   # set c = a + b c is the next number in fib 
8       write   r5         # print b printing value to the seq
9       addn    r6 1       # k = k + 1 moving to next number in seq
10      copy    r5 r4      # b = a the second number becomes the first in the seq
11      copy    r4 r7      # a = c the new number becomes the second in the seq
12      sub     r8 r6 r1   # r8 = k - n if value is zero end the sequence
13      jgtzn   r8 15      # If k > n goto ??
14      jumpn   7          # If not k > n, go back to line 7 (loop)
15      halt               # and return!
16      halt               # and return!

"""

# Set this variable to whichever program you want to execute
# when this file is loaded.
RunThis = Fibonacci

# Choose whether to use debug mode; uncomment one of the following lines.
# Mode = ['-n'] # not debug mode, 
Mode = ['-n'] # debug mode
#Mode = []     # prompt for whether to enter debug mode


# When you press F5 in IDLE, the following code will
# load the assembler and simulator, then run them.
# You can interrupt with Ctrl-C; then re-start Python.

if __name__ == "__main__" : 
    import hmmmAssembler ; importlib.reload(hmmmAssembler)
    import hmmmSimulator ; importlib.reload(hmmmSimulator)
    hmmmAssembler.main(RunThis) # assemble input into machine code file out.b
    hmmmSimulator.main(Mode)    # run the machine code in out.b


